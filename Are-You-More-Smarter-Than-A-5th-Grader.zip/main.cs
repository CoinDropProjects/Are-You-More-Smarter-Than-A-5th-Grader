using System;

class MainClass
 {
  public static void Main () 
  {
    Console.Clear();

    BootUp();
  }

  public static void BootUp()
  {
    Console.WriteLine("A 'Coin.Drop Projects' project.");
    Console.WriteLine();
    Console.WriteLine("Press Any Key To Continue...");
    Console.ReadKey();
    Console.Clear();
    Console.WriteLine("Built With The 'Repl.it' Online Compiler.");
    Console.WriteLine();
    Console.WriteLine("Press Any Key To Continue...");
    Console.ReadKey();
    Console.Clear();
    Console.WriteLine("'Are You More Smarterer Than A 5th Grader?'");
    Console.WriteLine();
    Console.WriteLine("Press Any Key To Continue...");
    Console.ReadKey();
    MainMenu();
  }

  public static void MainMenu()
  {
    Console.Clear();
    Console.WriteLine("=========================================");
    Console.WriteLine("Are You More Smarterer Than A 5th Grader?");
    Console.WriteLine("=========================================");
    Console.WriteLine();
    Console.WriteLine("1. Play");
    Console.WriteLine("2. Settings");
    Console.WriteLine("3. Exit");
    string menuChoice = Console.ReadLine();

    switch(menuChoice)
    {
      case "1":
      case "Play":
      case "play":

      Start();
      break;

      case "2":
      case "Settings":
      case "settings":

      Settings();
      break;

      case "3":
      case "Exit":
      case "exit":

      Exit();
      break;
    }
  }

  

  public static void Start()
  {
    Console.Clear();
    int userScore = 0;
    Return:
    Console.Clear();
    foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();  
        }
    int num1 = new System.Random().Next(11);
    int num2 = new System.Random().Next(11);
    Console.WriteLine("What Is " + num1 + " Times " + num2);
    int userChoice = Convert.ToInt32(Console.ReadLine());

    if(userChoice == num1 * num2)
    {
      foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();  
        }
      Console.WriteLine("Correct!");
      ++userScore;
      Console.WriteLine();
      Console.WriteLine("Your Score Is " + userScore);

      switch (userScore)
      {
        case 5:
        Console.WriteLine("Wow! You're on a Hot Streak!");
        break;
        case 10:
        Console.WriteLine("Can You Reach 20!");
        break;
        case 20:
        Console.WriteLine("Okay Hotshot! Let's Double It! Get a score of 40 and you'll get a surprise!");
        break;
        case 40:
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Red;
        }
        Console.Write("Y");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Red;
        }
        Console.Write("o");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Blue;
        }
        Console.Write("u");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Green;
        }
        Console.Write(" ");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        Console.Write("G");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.White;
        }
        Console.Write("a");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Red;
        }
        Console.Write("y");
        foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Blue;
        }
        Console.Write("!");

        break;
        case 80:
        Console.WriteLine("You Nerd! You actually have the patience for this... Get 160 and you will find nothing.. i thinnk...");
        break;
        case 160:
        Console.WriteLine("nothing..\n \nCan you get to 200? ");
        break;
        case 200:
        Console.WriteLine("Congrats you made it you can now leave if you want!");
        Console.WriteLine();
        Console.WriteLine("1. Yes");
        Console.WriteLine("2. No");
        string leaveGame = Console.ReadLine();

        if(leaveGame == "1")
        {
          MainMenu();
        }else if(leaveGame == "2")
        {
          goto Return;
        }
        break;
        
      }
      Console.ReadKey();
      goto Return;
    }else if(userChoice != num1 * num2)
    {
      foreach(ConsoleColor color in Enum.GetValues(typeof(ConsoleColor))) 
        {  
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Clear();  
        }
        Console.WriteLine("Incorrect! The Answer was " + num1 * num2);
        Console.WriteLine("You're Score is : " + --userScore);
        Console.ReadKey();
        goto Return;
    }else
    {
      MainMenu();
    }

  }

  public static void Settings()
  {
    Console.Clear();
    Console.WriteLine("JJust play the game dont woryy about settings...");
    Console.ReadKey();
    MainMenu();
  }

  public static void Exit()
  {

  }

 }